# tikape-runko

Tietokantojen perusteet -kurssilla tehtävän web-sovelluksen pohja.

